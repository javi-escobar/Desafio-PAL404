﻿using System;

namespace Compuertas_Logicas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowHeight = 40;
            Console.WindowWidth = 70;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.Title = "Compuertas Lógicas";
            Console.WriteLine("\n");
            //Declaración de Variables
            int opc;
            char v1, v2;
            Boolean bucle = true;
            //Entrada de Datos
            do {
                Console.Clear();
                Console.WriteLine("\tElige que compuerta lógica deseas calcular: ");
                Console.WriteLine("\t1- Compuerta XOR");
                Console.WriteLine("\t2- Compuerta NAND");
                Console.WriteLine("\t3- Salir del programa");
                opc = int.Parse(Console.ReadLine());
                switch (opc)
                {
                    case 1:
                        Console.WriteLine("\tIngrese los valores de la siguiente forma v=verdadero f=falso");
                        Console.WriteLine("\tIngrese el primer valor: ");
                        v1 = char.Parse(Console.ReadLine());
                        Console.WriteLine("\tIngrese el segundo valor: ");
                        v2 = char.Parse(Console.ReadLine());

                        if (v1 == 'f' && v2 == 'f' || v1 == 'F' && v2 == 'F' || v1 == 'f' && v2 == 'F' || v1 == 'F' && v2 == 'f')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'F'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        else if (v1 == 'v' && v2 == 'v' || v1 == 'V' && v2 == 'V' || v1 == 'v' && v2 == 'V' || v1 == 'V' && v2 == 'v')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'F'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        else if (v1 == 'f' && v2 == 'v' || v1 == 'F' && v2 == 'V' || v1 == 'F' && v2 == 'v' || v1 == 'f' && v2 == 'V')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'V'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        else if (v1 == 'v' && v2 == 'f' || v1 == 'V' && v2 == 'F' || v1 == 'V' && v2 == 'f' || v1 == 'v' && v2 == 'F')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'V'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        break;
                    case 2:
                        Console.WriteLine("\tIngrese los valores de la siguiente forma v=verdadero f=falso");
                        Console.WriteLine("\tIngrese el primer valor: ");
                        v1 = char.Parse(Console.ReadLine());
                        Console.WriteLine("\tIngrese el segundo valor: ");
                        v2 = char.Parse(Console.ReadLine());
                        if (v1 == 'f' && v2 == 'f' || v1 == 'F' && v2 == 'F' || v1 == 'f' && v2 == 'F' || v1 == 'F' && v2 == 'f')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'V'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        else if (v1 == 'v' && v2 == 'v' || v1 == 'V' && v2 == 'V' || v1 == 'v' && v2 == 'V' || v1 == 'V' && v2 == 'v')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'F'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        else if (v1 == 'f' && v2 == 'v' || v1 == 'F' && v2 == 'V' || v1 == 'F' && v2 == 'v' || v1 == 'f' && v2 == 'V')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'V'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        else if (v1 == 'v' && v2 == 'f' || v1 == 'V' && v2 == 'F' || v1 == 'V' && v2 == 'f' || v1 == 'v' && v2 == 'F')
                        {
                            Console.WriteLine("El resultado de la compuerta lógica es: 'V'");
                            Console.WriteLine("Presiona cualquier tecla para reiniciar el programa...");
                            Console.ReadKey();
                        }
                        break;
                    default:
                        Console.WriteLine("Ingrese una opción válida.");
                        break;
                }
                if (opc == 3)
                {
                    bucle = false;
                    Console.WriteLine("Presiona cualquier tecla para salir del programa...");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            } while (bucle);
        }
    }
}
